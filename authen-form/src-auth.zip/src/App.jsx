import Register from "./Register";
function App() {
  return (
    <>
      <Register />
    </>
  );
}

export default App;
