import axios from "axios";

export default axios.create({
  baseURL: "https://65e993bdc9bf92ae3d3989a4.mockapi.io",
});
