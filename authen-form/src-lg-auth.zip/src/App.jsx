// import Register from "./Register";
import Login from "./Login";
function App() {
  return (
    <>
      {/* <Register /> */}
      <Login />
    </>
  );
}

export default App;
