function AdminNav() {
  return <h1>SAHIL</h1>;
}

export default AdminNav;
