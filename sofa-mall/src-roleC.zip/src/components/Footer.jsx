

function Footer() {
  return (
    <div>
      <h3>Footer</h3>
      <p>This is a footer</p>
    </div>
  )
}

export default Footer