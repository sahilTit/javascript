
function Unauthorized() {
  return (
    <div>Unauthorized</div>
  )
}

export default Unauthorized